import { createBrowserRouter } from "react-router";
import { Layout } from "@/app/components/layout";
import { WelcomePage } from "@/app/pages/welcome";
import { LoginPage } from "@/app/pages/login";
import { DashboardPage } from "@/app/pages/dashboard";
import { TelemedPage } from "@/app/pages/telemed";
import { DoctorProfilePage } from "@/app/pages/doctor-profile";
import { ChatPage } from "@/app/pages/chat";
import { ClubhousePage } from "@/app/pages/clubhouse";
import { AudioRoomPage } from "@/app/pages/audio-room";
import { AssessmentPage } from "@/app/pages/assessment";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: WelcomePage },
      { path: "login", Component: LoginPage },
      { path: "dashboard", Component: DashboardPage },
      { path: "telemed", Component: TelemedPage },
      { path: "doctor/:id", Component: DoctorProfilePage },
      { path: "chat/:doctorId", Component: ChatPage },
      { path: "clubhouse", Component: ClubhousePage },
      { path: "room/:id", Component: AudioRoomPage },
      { path: "assessment", Component: AssessmentPage },
    ],
  },
]);
