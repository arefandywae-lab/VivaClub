import { Link } from "react-router";
import { Users, Mic, Heart } from "lucide-react";

const rooms = [
  {
    id: "1",
    topic: "Dealing with Burnout",
    participants: 24,
    gradient: "from-[var(--buttery-yellow)]/20 to-[var(--cotton-pink)]/20",
    borderColor: "border-[var(--cotton-pink)]/30",
  },
  {
    id: "2",
    topic: "Anxiety Management Techniques",
    participants: 18,
    gradient: "from-[var(--sky-blue)]/20 to-[var(--mint-green)]/20",
    borderColor: "border-[var(--mint-green)]/30",
  },
  {
    id: "3",
    topic: "Grief and Loss Support",
    participants: 12,
    gradient: "from-[var(--cotton-pink)]/20 to-[var(--sky-blue)]/20",
    borderColor: "border-[var(--cotton-pink)]/30",
  },
  {
    id: "4",
    topic: "Building Self-Confidence",
    participants: 31,
    gradient: "from-[var(--mint-green)]/20 to-[var(--buttery-yellow)]/20",
    borderColor: "border-[var(--buttery-yellow)]/30",
  },
  {
    id: "5",
    topic: "Mindfulness & Meditation",
    participants: 45,
    gradient: "from-[var(--sky-blue)]/20 to-[var(--cotton-pink)]/20",
    borderColor: "border-[var(--sky-blue)]/30",
  },
  {
    id: "6",
    topic: "Relationship Challenges",
    participants: 16,
    gradient: "from-[var(--cotton-pink)]/20 to-[var(--buttery-yellow)]/20",
    borderColor: "border-[var(--cotton-pink)]/30",
  },
];

export function ClubhousePage() {
  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-[var(--buttery-yellow)] to-[var(--cotton-pink)] p-6 text-[#2d3748]">
        <div className="flex items-center gap-2 mb-2">
          <Heart className="w-5 h-5" fill="#2d3748" />
          <span className="text-sm font-medium">Anonymous & Safe</span>
        </div>
        <h1 className="text-3xl font-semibold mb-2">Clubhouse</h1>
        <p className="text-[#2d3748]/80">Join anonymous audio rooms for support & connection</p>
      </div>

      <div className="max-w-screen-lg mx-auto p-6 space-y-4">
        {/* Info Card */}
        <div className="bg-[var(--cotton-pink)]/10 rounded-[1.5rem] p-5 border border-[var(--cotton-pink)]/20">
          <h3 className="font-medium text-foreground mb-2">Your Privacy is Protected</h3>
          <p className="text-sm text-muted-foreground">
            All conversations are anonymous. You'll be assigned a random avatar and alias. No personal information is shared.
          </p>
        </div>

        {/* Active Rooms */}
        <h2 className="text-xl font-semibold text-foreground pt-2">Active Rooms</h2>
        <div className="grid gap-4">
          {rooms.map((room) => (
            <Link
              key={room.id}
              to={`/room/${room.id}`}
              className={`block bg-gradient-to-br ${room.gradient} rounded-[1.5rem] p-6 border ${room.borderColor} shadow-sm hover:shadow-md transition-all group`}
            >
              <div className="flex items-start justify-between mb-3">
                <h3 className="text-lg font-semibold text-foreground group-hover:text-[var(--cotton-pink)] transition-colors">
                  {room.topic}
                </h3>
                <Mic className="w-5 h-5 text-[var(--cotton-pink)]" />
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="w-4 h-4" />
                <span>{room.participants} people listening</span>
              </div>
              <div className="mt-4 inline-flex items-center text-sm font-medium text-[var(--cotton-pink)] group-hover:gap-2 transition-all">
                Join Room
                <span className="ml-1 group-hover:ml-2 transition-all">→</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
