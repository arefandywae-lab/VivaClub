import { useState } from "react";
import { useNavigate } from "react-router";
import { Phone, Mail } from "lucide-react";

export function LoginPage() {
  const navigate = useNavigate();
  const [phone, setPhone] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login - in real app would authenticate
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-[var(--sky-blue)]/10 via-[var(--mint-green)]/10 to-[var(--cotton-pink)]/10">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-semibold text-foreground">Welcome Back</h1>
          <p className="text-muted-foreground">Sign in to continue your journey</p>
        </div>

        <div className="bg-card rounded-[1.5rem] p-8 shadow-xl border border-border">
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground flex items-center gap-2">
                <Phone className="w-4 h-4" />
                Phone Number
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Enter your phone number"
                className="w-full px-4 py-3 rounded-[1rem] bg-input-background border border-border focus:outline-none focus:ring-2 focus:ring-[var(--sky-blue)] transition-all"
              />
            </div>

            <button
              type="submit"
              className="w-full py-4 px-6 bg-gradient-to-r from-[var(--sky-blue)] to-[var(--mint-green)] text-white rounded-[1.5rem] font-medium shadow-lg hover:shadow-xl transition-all"
            >
              Continue
            </button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-card text-muted-foreground">Or continue with</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => navigate("/dashboard")}
              className="w-full py-4 px-6 bg-white border-2 border-border rounded-[1.5rem] font-medium hover:bg-muted transition-all flex items-center justify-center gap-2"
            >
              <Mail className="w-5 h-5" />
              Sign in with Google
            </button>
          </form>

          <p className="mt-6 text-xs text-center text-muted-foreground">
            By continuing, you agree to our Terms of Service and Privacy Policy
          </p>
        </div>
      </div>
    </div>
  );
}
