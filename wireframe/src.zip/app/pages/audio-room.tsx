import { useState } from "react";
import { Link, useParams } from "react-router";
import { ArrowLeft, Mic, MicOff, Volume2, LogOut } from "lucide-react";

const avatarColors = [
  "bg-[var(--sky-blue)]",
  "bg-[var(--mint-green)]",
  "bg-[var(--buttery-yellow)]",
  "bg-[var(--cotton-pink)]",
  "bg-purple-300",
  "bg-indigo-300",
];

const anonymousNames = [
  "Anonymous Panda",
  "Quiet Star",
  "Gentle Wave",
  "Peaceful Cloud",
  "Kind Heart",
  "Brave Soul",
  "Calm Spirit",
  "Wise Owl",
];

const participants = [
  { id: 1, name: "Anonymous Panda", speaking: true, muted: false },
  { id: 2, name: "Quiet Star", speaking: false, muted: false },
  { id: 3, name: "Gentle Wave", speaking: false, muted: false },
  { id: 4, name: "Peaceful Cloud", speaking: true, muted: false },
  { id: 5, name: "Kind Heart", speaking: false, muted: true },
  { id: 6, name: "Brave Soul", speaking: false, muted: true },
  { id: 7, name: "Calm Spirit", speaking: false, muted: true },
  { id: 8, name: "Wise Owl", speaking: false, muted: true },
];

export function AudioRoomPage() {
  const { id } = useParams();
  const [isMuted, setIsMuted] = useState(true);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[var(--buttery-yellow)]/10 via-[var(--cotton-pink)]/10 to-[var(--sky-blue)]/10">
      {/* Header */}
      <div className="bg-gradient-to-r from-[var(--buttery-yellow)] to-[var(--cotton-pink)] p-6 text-[#2d3748]">
        <Link to="/clubhouse" className="inline-flex items-center gap-2 mb-4 text-[#2d3748]/70 hover:text-[#2d3748]">
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Lobby</span>
        </Link>
        <h1 className="text-2xl font-semibold">Dealing with Burnout</h1>
        <p className="text-[#2d3748]/80 text-sm mt-1">24 people in this room</p>
      </div>

      <div className="max-w-screen-lg mx-auto p-6 space-y-6 pb-24">
        {/* Your Identity */}
        <div className="bg-card rounded-[1.5rem] p-5 border border-border shadow-sm">
          <h3 className="font-medium text-foreground mb-3">You are:</h3>
          <div className="flex items-center gap-3">
            <div className={`w-16 h-16 rounded-full ${avatarColors[0]} flex items-center justify-center`}>
              <span className="text-2xl">🐼</span>
            </div>
            <div>
              <p className="font-medium text-foreground">{anonymousNames[0]}</p>
              <p className="text-sm text-muted-foreground">Your identity is protected</p>
            </div>
          </div>
        </div>

        {/* Stage - Active Speakers */}
        <div className="bg-card rounded-[1.5rem] p-6 border border-border shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <Volume2 className="w-5 h-5 text-[var(--cotton-pink)]" />
            <h3 className="font-medium text-foreground">On Stage</h3>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {participants
              .filter((p) => p.speaking)
              .map((participant, i) => (
                <div key={participant.id} className="flex flex-col items-center gap-2">
                  <div className="relative">
                    <div
                      className={`w-20 h-20 rounded-full ${avatarColors[i % avatarColors.length]} flex items-center justify-center ring-4 ring-[var(--cotton-pink)]/20`}
                    >
                      <span className="text-3xl">{["🐼", "⭐", "🌊", "☁️"][i]}</span>
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-[var(--mint-green)] flex items-center justify-center shadow-md">
                      <Mic className="w-4 h-4 text-white" />
                    </div>
                  </div>
                  <p className="text-sm font-medium text-foreground text-center">{participant.name}</p>
                </div>
              ))}
          </div>
        </div>

        {/* Listeners */}
        <div className="bg-card rounded-[1.5rem] p-6 border border-border shadow-sm">
          <h3 className="font-medium text-foreground mb-4">Listeners</h3>
          <div className="grid grid-cols-4 gap-4">
            {participants
              .filter((p) => !p.speaking)
              .map((participant, i) => (
                <div key={participant.id} className="flex flex-col items-center gap-2">
                  <div className="relative">
                    <div
                      className={`w-16 h-16 rounded-full ${avatarColors[(i + 2) % avatarColors.length]} flex items-center justify-center opacity-70`}
                    >
                      <span className="text-2xl">{["💝", "🦉", "🌟", "🌸"][i]}</span>
                    </div>
                    {participant.muted && (
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-muted flex items-center justify-center">
                        <MicOff className="w-3 h-3 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground text-center truncate w-full">
                    {participant.name}
                  </p>
                </div>
              ))}
          </div>
        </div>

        {/* Controls */}
        <div className="fixed bottom-20 left-0 right-0 p-6 bg-gradient-to-t from-background via-background to-transparent">
          <div className="max-w-screen-lg mx-auto flex items-center justify-center gap-4">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`w-16 h-16 rounded-full ${
                isMuted
                  ? "bg-muted hover:bg-muted/80"
                  : "bg-gradient-to-r from-[var(--mint-green)] to-[var(--sky-blue)]"
              } flex items-center justify-center shadow-lg transition-all`}
            >
              {isMuted ? (
                <MicOff className="w-7 h-7 text-muted-foreground" />
              ) : (
                <Mic className="w-7 h-7 text-white" />
              )}
            </button>

            <Link
              to="/clubhouse"
              className="px-6 py-3 bg-card border-2 border-border rounded-[1rem] font-medium hover:bg-muted transition-all flex items-center gap-2"
            >
              <LogOut className="w-5 h-5" />
              Leave Quietly
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
