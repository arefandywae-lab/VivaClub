import { Outlet, useLocation, Link } from "react-router";
import { Home, Video, Users, User } from "lucide-react";

export function Layout() {
  const location = useLocation();
  const showNav = !["/", "/login"].includes(location.pathname);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="flex-1 overflow-auto">
        <Outlet />
      </div>

      {showNav && (
        <nav className="bg-card border-t border-border">
          <div className="max-w-screen-lg mx-auto flex justify-around py-4 px-4">
            <Link
              to="/dashboard"
              className={`flex flex-col items-center gap-1 transition-colors ${
                location.pathname === "/dashboard"
                  ? "text-[var(--sky-blue)]"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Home className="w-6 h-6" />
              <span className="text-xs">Home</span>
            </Link>

            <Link
              to="/telemed"
              className={`flex flex-col items-center gap-1 transition-colors ${
                location.pathname.startsWith("/telemed") ||
                location.pathname.startsWith("/doctor") ||
                location.pathname.startsWith("/chat")
                  ? "text-[var(--sky-blue)]"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Video className="w-6 h-6" />
              <span className="text-xs">Telemed</span>
            </Link>

            <Link
              to="/clubhouse"
              className={`flex flex-col items-center gap-1 transition-colors ${
                location.pathname.startsWith("/clubhouse") ||
                location.pathname.startsWith("/room")
                  ? "text-[var(--mint-green)]"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Users className="w-6 h-6" />
              <span className="text-xs">Clubhouse</span>
            </Link>

            <Link
              to="/dashboard"
              className={`flex flex-col items-center gap-1 transition-colors text-muted-foreground hover:text-foreground`}
            >
              <User className="w-6 h-6" />
              <span className="text-xs">Profile</span>
            </Link>
          </div>
        </nav>
      )}
    </div>
  );
}
